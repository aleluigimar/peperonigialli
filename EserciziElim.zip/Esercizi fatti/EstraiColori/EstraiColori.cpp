#include <iostream>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>


using namespace cv;
using namespace std;



Mat estraiColori(Mat imgInput, int *r, int *g, int *b){

	Mat imgOutput = Mat::zeros(imgInput.size(),imgInput.type());
	int N = imgInput.rows, M = imgInput.cols;

	for(int i=0; i<N; i++)
		for(int j=0; j<M; j++){
			Vec3b tmp = imgInput.at<Vec3b>(i,j);
			if(tmp.val[0] >= b[0] && tmp.val[0] <= b[1] ||
			   tmp.val[1] >= g[0] && tmp.val[1] <= g[1] ||
			   tmp.val[2] >= r[0] && tmp.val[2] <= r[1] )
				 	imgOutput.at<Vec3b>(i,j) = tmp;
			else
					imgOutput.at<Vec3b>(i,j) = 0;
		}

	return imgOutput;


}



int main ( int argc, char **argv){


	Mat imgInput(imread( argv[1], 1));
	Mat imgOutput;
	int blue[2] = {10,20};
	int green[2] = {10,20};
	int red[2] = {220,255};

	if(argc  != 2){
		perror("Error: not enough arguments. Insert an img\n");
		exit(-1);
	}

	if( !imgInput.data ){
		cout<<"No img data"<<endl;
		return -1;
	}


	imgOutput = estraiColori(imgInput, red, green, blue);


	namedWindow("Display img", 0);
	imshow("Display img", imgInput);

	namedWindow("Segmentazione a colori", 0);
	imshow("Segmentazione a colori", imgOutput);

	waitKey();


	return 0;

}
