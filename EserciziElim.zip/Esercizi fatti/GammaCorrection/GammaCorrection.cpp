#include <stdio.h>
#include <iostream>
#include <cmath>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

using namespace std;
using namespace cv;


Mat gammaCorrection(Mat imgInput){

	Mat imgOutput = imgInput.clone();

	for(int i = 0; i < imgInput.rows; i++)
		for(int j = 0; j < imgInput.cols; j++)
			for(int k = 0; k < 3; k++)
				imgOutput.at<Vec3b>(i,j).val[k] = 20 * pow(imgOutput.at<Vec3b>(i,j).val[k],0.5);

	return imgOutput;

}



int main ( int argc, char **argv){


	if(argc  != 2){
		perror("Error: not enough arguments. Insert an image\n");
		exit(-1);
	}

	Mat imgInput(imread(argv[1],1));

	if( !imgInput.data ){
		cout<<"No image data"<<endl;
		return -1;
	}


	Mat imgOutput = gammaCorrection(imgInput);

	namedWindow("Image input",0);
	imshow("Image input",imgInput);
	namedWindow("Image output",0);
	imshow("Image output",imgOutput);

	waitKey();

	return 0;

}
