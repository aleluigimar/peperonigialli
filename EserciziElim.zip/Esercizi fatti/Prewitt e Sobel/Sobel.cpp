#include <stdio.h>
#include <iostream>
#include <vector>
#include <math.h>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

Mat gaussianBlur(int N, int M, Mat imgInput){

	int sum=0, denominatore = 0;
	Mat imgOutput(imgInput.clone());
	float mask[3*3] =
	{
		1/16.0,2/16.0,1/16.0,
		2/16.0,4/16.0,2/16.0,
		1/16.0,2/16.0,1/16.0
	};

	for(int i=1; i<N-1; i++){
		for(int j=1; j<M-1; j++){
			sum=0;
			for(int w = -1; w <= 1 ; w++){
				for(int k=-1; k<=1;k++){
					sum = sum + ( imgInput.at<uchar>(i+w,j+k) * mask[k+w+2] );
				}
			}
			imgOutput.at<uchar>(i,j) = sum;
		}
	}

		return imgOutput;

}


int main(int argc, char const *argv[]) {

  if(argc != 2){
    perror("Missing input <image>");
    exit(-1);
  }

  Mat imgInput(imread(argv[1],0)), imgOutput(imgInput.clone());

  if(!imgInput.data){
    perror("No image data");
    exit(-1);
  }

  int N = imgInput.rows, M = imgInput.cols;

  int gradX = 0, gradY = 0, gradiente = 0;

  imgInput = gaussianBlur(N,M,imgInput);

  for(int i=1; i<N-1; i++)
    for(int j=1; j<M-1;j++){
      gradX =
        imgInput.at<uchar>(i-1,j+1) + 2 * imgInput.at<uchar>(i,j+1) + imgInput.at<uchar>(i+1,j+1) -
        (imgInput.at<uchar>(i-1,j-1) + 2 * imgInput.at<uchar>(i,j-1) + imgInput.at<uchar>(i+1,j-1));
      gradY =
        imgInput.at<uchar>(i+1,j-1) + 2 * imgInput.at<uchar>(i+1,j) + imgInput.at<uchar>(i+1,j+1) -
        (imgInput.at<uchar>(i-1,j-1) + 2 * imgInput.at<uchar>(i-1,j) + imgInput.at<uchar>(i-1,j+1));

        gradiente = abs(gradX) + abs(gradY);
        gradiente = gradiente > 255 ? 255 : gradiente;
        gradiente = gradiente < 0 ? 0 : gradiente;

        imgOutput.at<uchar>(i,j) = gradiente;
    }




  namedWindow("Immagine di partenza", 0);
  imshow("Immagine di partenza", imgInput);

  namedWindow("Immagine filtrata", 0);
  imshow("Immagine filtrata", imgOutput);

  waitKey(0);
  destroyAllWindows();

  return 0;
}
