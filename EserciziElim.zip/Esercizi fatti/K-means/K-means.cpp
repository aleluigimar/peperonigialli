#include <iostream>
#include <time.h>
#include <vector>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

using namespace cv;
using namespace std;


double distanza(Vec3b punto, Vec3b centr){

	return sqrt(
                pow(centr.val[0] - punto.val[0], 2) +
                pow(centr.val[1] - punto.val[1], 2) +
                pow(centr.val[2] - punto.val[2], 2)
			);
	
}

Mat kMeans(Mat imgInput,Mat clusters, int knumber){

	double min = 0.0, dist = 0.0;
	int id_centr = 0, z = 0;
	Vec3b val_centr;
	Mat imgOutput = imgInput.clone(), oldclusters = clusters.clone();
	bool finito = false;


	while(!finito && z < 100){

		for(int i = 0; i < knumber; i++)
        	oldclusters.at<Vec3b>(0, i) = clusters.at<Vec3b>(0, i);

		for(int y = 0; y < imgInput.rows; y++)
        	for(int x = 0; x < imgInput.cols; x++){ 
            	min = distanza(imgOutput.at<Vec3b>(y, x), clusters.at<Vec3b>(0, 0)); 

  		  		for(int i = 1; i < knumber; i++){ 
        		
					dist = distanza(imgOutput.at<Vec3b>(y, x), clusters.at<Vec3b>(0, i)); 
				
					if(dist < min) {
                    	min = dist;
                    	id_centr = i;
                    	val_centr = clusters.at<Vec3b>(0, i);
                	}
				}

				imgOutput.at<Vec3b>(y,x) = val_centr;

				clusters.at<Vec3b>(0,id_centr).val[0] = (int)((clusters.at<Vec3b>(0,id_centr).val[0] + val_centr.val[0]) / 2.0);
				clusters.at<Vec3b>(0,id_centr).val[1] = (int)((clusters.at<Vec3b>(0,id_centr).val[1] + val_centr.val[1]) / 2.0);
				clusters.at<Vec3b>(0,id_centr).val[2] = (int)((clusters.at<Vec3b>(0,id_centr).val[2] + val_centr.val[2]) / 2.0);

			}

    		for(int i = 0; i < knumber; i++)
        		if(clusters.at<Vec3b>(0, i) != oldclusters.at<Vec3b>(0, i)) {
            		finito = true;
            		oldclusters.at<Vec3b>(0, i) = clusters.at<Vec3b>(0, i);
        		}
	
			z++;

	}

	return imgOutput;
}





int main ( int argc, char **argv){



	srand((unsigned)time(NULL));
	if(argc  != 2){
		perror("Error: not enough arguments. Insert an img\n");
		exit(-1);
	}

    Mat imgInput(imread(argv[1],1));
	if( !imgInput.data ){
		cout<<"No img data"<<endl;
		return -1;
	}

	int knumber = 5, N = imgInput.rows, M = imgInput.cols;
    vector<int> clus_x, clus_y;
	Mat clusters = Mat::zeros(imgInput.size(),imgInput.type()),	imgOutput = Mat::zeros(imgInput.size(),imgInput.type());


	for(int j = 0; j < knumber; j++){
		clus_x.push_back(rand() % N);
		clus_y.push_back(rand() % M);
		clusters.at<Vec3b>(0,j) = imgInput.at<Vec3b>(clus_x[j],clus_y[j]);
	}
	


	imgOutput = kMeans(imgInput, clusters, knumber);
    
    namedWindow("Input image", 0);
	imshow("Input image",imgInput);
    namedWindow("K-means", 0);
	imshow("K-means",imgOutput);

    waitKey();


	return 0;

}
