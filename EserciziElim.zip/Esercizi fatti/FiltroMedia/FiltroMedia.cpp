#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;



Mat filtroMediaMobile(Mat imgInput){

		Mat imgOutput = imgInput.clone();
		int N = imgInput.rows, M = imgInput.cols;

		for(int i=1;i<N-1;i++)
			for(int j=1;j<M-1;j++){
				uchar vector[9];

				vector[0]= imgInput.at<uchar>(i,j);
				vector[1]= imgInput.at<uchar>(i-1,j);
				vector[2]= imgInput.at<uchar>(i+1,j);

				vector[3]= imgInput.at<uchar>(i,j-1);
				vector[4]= imgInput.at<uchar>(i,j+1);

				vector[5]= imgInput.at<uchar>(i-1,j-1);
				vector[6]= imgInput.at<uchar>(i+1,j+1);

				vector[7]= imgInput.at<uchar>(i-1,j+1);
				vector[8]= imgInput.at<uchar>(i+1,j-1);

				uchar val = (vector[0]+vector[1]+vector[2]+vector[3]+vector[4]+vector[5]+vector[6]+vector[7]+vector[8])/9;
				imgOutput.at<uchar>(i,j)=val;
			}


		return imgOutput;

}



int main(int argc , char **argv)
{
	if(argc != 2)
	{
		cout<<"Inserire immagine";
		return -1;
	}
	Mat imgInput(imread( argv[1],0));
	Mat imgOutput = imgInput.clone();

	if(!imgInput.data)
	{
		cout<<"No image data";
		return -1;
	}

	imgOutput = filtroMediaMobile(imgInput);

	namedWindow("Original",0);
	imshow("Original",imgInput);
	namedWindow("Filtro Media",0);
	imshow("Filtro Media",imgOutput);

	waitKey(0);
	return 0;

}
