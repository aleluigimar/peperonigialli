#include <stdio.h>
#include <iostream>
#include <vector>
#include <math.h>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;


Mat gaussianBlur(Mat imgInput){

	int sum=0, denominatore = 0, N = imgInput.rows, M = imgInput.cols;
	Mat imgOutput = Mat::zeros(imgInput.size(),imgInput.type());
	float mask[3*3] =
	{
		1.0,2.0,1.0,
		2.0,4.0,2.0,
		1.0,2.0,1.0
	};

	for(int i=1; i<N-1; i++){
		for(int j=1; j<M-1; j++){
			sum=0;
			for(int w = -1; w <= 1 ; w++){
				for(int k=-1; k<=1;k++){
					sum = sum + ( imgInput.at<uchar>(i+w,j+k) * mask[k+w+2] );
				}
			}
			imgOutput.at<uchar>(i,j) = sum / 16;
		}
	}

		return imgOutput;

}


Mat roberts(Mat imgInput, double **direzioneGradiente){

  int gradX = 0, gradY = 0, gradiente = 0, N = imgInput.rows, M = imgInput.cols;
  Mat imgOutput = Mat::zeros(imgInput.size(),imgInput.type());

  for(int i=1; i<N-1; i++)
    for(int j=1; j<M-1;j++){
      gradX = imgInput.at<uchar>(i+1,j+1) - imgInput.at<uchar>(i,j);
      gradY = imgInput.at<uchar>(i+1,j) - imgInput.at<uchar>(i,j+1);
			gradiente = abs(gradX) + abs(gradY);
			gradiente = gradiente > 255 ? 255 : gradiente;
			gradiente = gradiente < 0 ? 0 : gradiente;
      imgOutput.at<uchar>(i,j) = gradiente;
			direzioneGradiente[i][j] = atan2(gradY,gradX);
    }

  return imgOutput;

}


Mat nonMaxSuppression(Mat imgInput, double **direzioneGradiente){

int N = imgInput.rows, M = imgInput.cols, pixel_prec = 0;
Mat imgOutput = imgInput.clone();

for(int y = 1; y < N - 1; y++)
		for(int x = 1; x < M - 1; x++) {
				if(direzioneGradiente[y][x] >= 0 && direzioneGradiente[y][x] <= M_PI/6)
						if(imgInput.at<uchar>(y, x) <= imgInput.at<uchar>(y, x-1) || imgInput.at<uchar>(y, x) <= imgInput.at<uchar>(y, x+1))
								imgOutput.at<uchar>(y, x) = 0;
				if(direzioneGradiente[y][x] > M_PI/6 && direzioneGradiente[y][x] <= M_PI/3)
						if(imgInput.at<uchar>(y, x) <= imgInput.at<uchar>(y, x-1) || imgInput.at<uchar>(y, x) <= imgInput.at<uchar>(y, x+1))
								imgOutput.at<uchar>(y, x) = 0;
				if(direzioneGradiente[y][x] > M_PI/3 && direzioneGradiente[y][x] <= M_PI/2)
						if(imgInput.at<uchar>(y, x) <= imgInput.at<uchar>(y, x-1) || imgInput.at<uchar>(y, x) <= imgInput.at<uchar>(y, x+1))
								imgOutput.at<uchar>(y, x) = 0;
				if(direzioneGradiente[y][x] > M_PI/2 && direzioneGradiente[y][x] <= (3/4)*M_PI)
						if(imgInput.at<uchar>(y, x) <= imgInput.at<uchar>(y, x-1) || imgInput.at<uchar>(y, x) <= imgInput.at<uchar>(y, x+1))
								imgOutput.at<uchar>(y, x) = 0;
		}


return imgOutput;

}



Mat hysteresis(Mat imgInput, double t_min, double t_max){

int N = imgInput.rows, M = imgInput.cols;
Mat imgOutput = imgInput.clone();

	for(int x = 1; x < N - 1; x++)
		for(int y = 1; y < M - 1; y++){
			int pixel_curr = imgInput.at<uchar>(x,y);
			if(pixel_curr >= t_max)
				imgOutput.at<uchar>(x,y) = 255;
			else if(pixel_curr < t_min)
				imgOutput.at<uchar>(x,y) = 0;
			else{
				if(imgOutput.at<uchar>(x+1,y) >= t_max
				|| imgOutput.at<uchar>(x-1,y) >= t_max
				|| imgOutput.at<uchar>(x,y+1) >= t_max
				|| imgOutput.at<uchar>(x,y-1) >= t_max)
					imgOutput.at<uchar>(x,y) = 255;
				else
					imgOutput.at<uchar>(x,y) = 0;
			}
		}

		return imgOutput;


}




int main(int argc, char const *argv[]) {

  if(argc != 2){
    perror("Missing input <image>");
    exit(-1);
  }

  double t_min = 0.0, t_max = 0.0;
	int kernel_size = 3;
  Mat imgInput(imread(argv[1],0)), imgOutput = Mat::zeros(imgInput.size(),imgInput.type());
  Mat roberts_processed;


  if(!imgInput.data){
    perror("No image data");
    exit(-1);
  }

  int N = imgInput.rows, M = imgInput.cols;
	double **direzioneGradiente;
	direzioneGradiente = new double *[N];
	for(int i = 0; i < N; i++)
			direzioneGradiente[i] = new double [M];

  cout<<"Inserisci valori soglie di isteresi (t_min, t_max)"<<endl;
  cin>>t_min;
  cin>>t_max;

  roberts_processed = roberts(gaussianBlur(imgInput),direzioneGradiente);
  imgOutput = hysteresis(nonMaxSuppression(roberts_processed,direzioneGradiente),t_min, t_max);

	Mat cannyOCV = Mat::zeros(imgInput.size(),imgInput.type());
	Canny(imgInput,cannyOCV,t_min,t_max,kernel_size);

  namedWindow("Immagine di partenza", 0);
  imshow("Immagine di partenza", imgInput);

  namedWindow("cannyOCV", 0);
  imshow("cannyOCV", cannyOCV);

  namedWindow("Canny", 0);
  imshow("Canny", imgOutput);

  waitKey(0);
  destroyAllWindows();

	delete(direzioneGradiente);
  return 0;
}
