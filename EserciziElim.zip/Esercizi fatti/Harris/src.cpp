#include <stdio.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <cmath>
#include <iostream>
#include <vector>

using namespace std;
using namespace cv;

Mat filtroGaussiano(Mat s) {
	Mat img(Mat::zeros(s.rows,s.cols,s.type()));

	int gaussianMask[][3] = 
	{
		{1,2,1},
		{2,4,2},
		{1,2,1}
	};
	int divisor = 16;

	for (int i=1; i<s.rows-1; i++) {
		for (int j=1; j<s.cols-1; j++) {
			int newPixel = 
				s.at<uchar>(i-1,j-1) * gaussianMask[0][0] +
				s.at<uchar>(i-1,j) * gaussianMask[0][1] +
				s.at<uchar>(i-1,j+1) * gaussianMask[0][2] +
				s.at<uchar>(i,j-1) * gaussianMask[1][0] +
				s.at<uchar>(i,j) * gaussianMask[1][1] +
				s.at<uchar>(i,j+1) * gaussianMask[1][2] +
				s.at<uchar>(i+1,j-1) * gaussianMask[2][0] +
				s.at<uchar>(i+1,j) * gaussianMask[2][1] +
				s.at<uchar>(i+1,j+1) * gaussianMask[2][2]
			;
			newPixel = newPixel / divisor;
			newPixel = newPixel > 255 ? 255 : newPixel;

			img.at<uchar>(i,j) = newPixel;
		}
	}

	return img;
}

void calcoloGradienti(Mat s, Mat xg, Mat yg) {
	int xGradientMask[][3] = 
	{
		{-1,0,1},
		{-2,0,2},
		{-1,0,1}
	};

	int yGradientMask[][3] = 
	{
		{-1,-2,-1},
		{0,0,0},
		{1,2,1}
	};

	for (int i=1; i<s.rows-1; i++) {
		for (int j=1; j<s.cols-1; j++) {
			int xGradient = 
				s.at<uchar>(i-1,j-1) * xGradientMask[0][0] +
				s.at<uchar>(i-1,j) * xGradientMask[0][1] +
				s.at<uchar>(i-1,j+1) * xGradientMask[0][2] +
				s.at<uchar>(i,j-1) * xGradientMask[1][0] +
				s.at<uchar>(i,j) * xGradientMask[1][1] +
				s.at<uchar>(i,j+1) * xGradientMask[1][2] +
				s.at<uchar>(i+1,j-1) * xGradientMask[2][0] +
				s.at<uchar>(i+1,j) * xGradientMask[2][1] +
				s.at<uchar>(i+1,j+1) * xGradientMask[2][2]
			;
			int yGradient = 
				s.at<uchar>(i-1,j-1) * yGradientMask[0][0] +
				s.at<uchar>(i-1,j) * yGradientMask[0][1] +
				s.at<uchar>(i-1,j+1) * yGradientMask[0][2] +
				s.at<uchar>(i,j-1) * yGradientMask[1][0] +
				s.at<uchar>(i,j) * yGradientMask[1][1] +
				s.at<uchar>(i,j+1) * yGradientMask[1][2] +
				s.at<uchar>(i+1,j-1) * yGradientMask[2][0] +
				s.at<uchar>(i+1,j) * yGradientMask[2][1] +
				s.at<uchar>(i+1,j+1) * yGradientMask[2][2]
			;

			xGradient = xGradient > 255 ? 255 : xGradient;
			xGradient = xGradient < 0 ? 0 : xGradient;
			yGradient = yGradient > 255 ? 255 : yGradient;
			yGradient = yGradient < 0 ? 0 : yGradient;

			xg.at<uchar>(i,j) = xGradient;
			yg.at<uchar>(i,j) = yGradient;
		}
	}
}

void stampaGradientiDiSobel(Mat xg, Mat yg) {
	Mat img(Mat::zeros(xg.rows,xg.cols,xg.type()));

	for (int i=1; i<xg.rows-1; i++) {
		for (int j=1; j<xg.cols-1; j++) {
			int totalGradient = sqrt(pow(xg.at<uchar>(i,j),2) + pow(yg.at<uchar>(i,j),2));

			//totalGradient = totalGradient > 255 ? 255 : totalGradient;

			img.at<uchar>(i,j) = totalGradient;
		}
	}

	imshow("Immagine gradienti di Sobel", img);
}

void harrisCornerDetector(Mat img, Mat xg, Mat yg) {
	Mat  x2y2, xy2, traceM2, prova;
	int xGradPow2[img.rows][img.cols], yGradPow2[img.rows][img.cols], xyGradient[img.rows][img.cols], R[img.rows][img.cols];
	float Harris[img.rows][img.cols];
	int max, min;

	// Calcolo delle potenze dei gradienti
	for(int i=0; i<xg.rows; i++) {
        for(int j=0; j<xg.cols; j++) {
        	xGradPow2[i][j] = xg.at<uchar>(i,j) * xg.at<uchar>(i,j);
        }
    }
    for(int i=0; i<yg.rows; i++) {
        for(int j=0; j<yg.cols; j++) {
        	yGradPow2[i][j] = yg.at<uchar>(i,j) * yg.at<uchar>(i,j);
        }
    }

  	// moltiplicazione delle direzioni dei gradienti
  	for(int i=0; i<yg.rows; i++) {
        for(int j=0; j<yg.cols; j++) {
        	xyGradient[i][j] = xg.at<uchar>(i,j) * yg.at<uchar>(i,j);
        }
    }

    // Calcolo di R -> R = det(M) - k(trace(M))^2
    for(int i=0; i<img.rows; i++) {
        for(int j=0; j<img.cols; j++) {
        	R[i][j] = 
        	(
        		xGradPow2[i][j] * yGradPow2[i][j] - 
        		xyGradient[i][j] * xyGradient[i][j]
        	) -0.04 * ((xGradPow2[i][j] + yGradPow2[i][j]) * (xGradPow2[i][j] + yGradPow2[i][j]));
        }
    }
    min = R[0][0];
    max = R[0][0];
    for(int i=0; i<img.rows; i++) {
        for(int j=0; j<img.cols; j++) {
        	if (R[i][j] < min) {
        		min = R[i][j];
        	} else if (R[i][j] > max) {
        		max = R[i][j];
        	}
        }
    }
    printf("Min: %d - Max: %d\n", min, max);
    for(int i=0; i<img.rows; i++) {
        for(int j=0; j<img.cols; j++) {
        	Harris[i][j] = (float)(R[i][j] - min)/(float)(max - min); 
        }
    }

    for(int i=0; i<img.rows; i++) {
        for(int j=0; j<img.cols; j++) {
        	if (Harris[i][j] > 0.50f) {
        		circle(img, Point(j,i), 3, Scalar(0,0,0), 2, 8, 0);
        	}
        }
    }

    imshow("Immagine con i cerchi DEFINITIVO!!!?!?!?!!111", img);
    
}

int main (int argc, char** argv) {

	// prendo in input la matrice, e gli applico un filtro gaussiano prima del calcolo dei gradienti
	Mat imgOriginale(imread(argv[1],0));
	imshow("Immagine originale", imgOriginale);

	// matrice dei gradienti secondo la direzione X, y e x*y
	Mat xGradientWithSobel(Mat::zeros(imgOriginale.rows,imgOriginale.cols,imgOriginale.type()));
	Mat yGradientWithSobel(Mat::zeros(imgOriginale.rows,imgOriginale.cols,imgOriginale.type()));
	Mat xyGradient(Mat::zeros(imgOriginale.rows,imgOriginale.cols,imgOriginale.type()));

	// calcolo i gradienti secondo le maschere di Sobel
	calcoloGradienti(imgOriginale,xGradientWithSobel,yGradientWithSobel);
	stampaGradientiDiSobel(xGradientWithSobel,yGradientWithSobel);

	// mo avessma fà harris, speriamo bene...
	harrisCornerDetector(imgOriginale,xGradientWithSobel,yGradientWithSobel);

	waitKey();

	return 0;
}