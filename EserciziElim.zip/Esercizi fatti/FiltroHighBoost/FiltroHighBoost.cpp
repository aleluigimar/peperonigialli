#include <stdio.h>
#include <iostream>
#include <vector>
#include <math.h>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;


Mat filtroMediaMobile(Mat imgInput){

		Mat imgOutput = imgInput.clone();
		int N = imgInput.rows, M = imgInput.cols;

		for(int i=1;i<N-1;i++)
			for(int j=1;j<M-1;j++){
				uchar vector[9];

				vector[0]= imgInput.at<uchar>(i,j);
				vector[1]= imgInput.at<uchar>(i-1,j);
				vector[2]= imgInput.at<uchar>(i+1,j);

				vector[3]= imgInput.at<uchar>(i,j-1);
				vector[4]= imgInput.at<uchar>(i,j+1);

				vector[5]= imgInput.at<uchar>(i-1,j-1);
				vector[6]= imgInput.at<uchar>(i+1,j+1);

				vector[7]= imgInput.at<uchar>(i-1,j+1);
				vector[8]= imgInput.at<uchar>(i+1,j-1);

				uchar val = (vector[0]+vector[1]+vector[2]+vector[3]+vector[4]+vector[5]+vector[6]+vector[7]+vector[8])/9;
				imgOutput.at<uchar>(i,j)=val;
			}


		return imgOutput;

}





int main(int argc, char const *argv[]) {

  if(argc != 2){
    perror("Missing input <image>");
    exit(-1);
  }

  Mat imgInput(imread(argv[1],0)), highBoostOutput1, highBoostOutput2, unsharpOutput, LP, HP;
  double A;

  if(!imgInput.data){
    perror("No image data");
    exit(-1);
  }

  cout<<"Inserisci fattore di amplificazione: ";
  cin>>A;

  LP = filtroMediaMobile(imgInput);
  HP = imgInput - LP;
  highBoostOutput1 = imgInput * (A-1) + HP;
  highBoostOutput2 = imgInput + HP * (A-1);
	unsharpOutput = imgInput + HP;

  namedWindow("Immagine di partenza", 0);
  imshow("Immagine di partenza", imgInput);

  namedWindow("Immagine high boost 1", 0);
  imshow("Immagine high boost 1", highBoostOutput1);

  namedWindow("Immagine high boost 2", 0);
  imshow("Immagine high boost 2", highBoostOutput2);

	namedWindow("Immagine unsharp", 0);
  imshow("Immagine unsharp", unsharpOutput);

  waitKey();

  return 0;
}
