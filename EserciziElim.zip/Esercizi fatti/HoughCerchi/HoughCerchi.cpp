#include <stdio.h>
#include <iostream>
#include <math.h>
#include <cmath>
#include <vector>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>


using namespace cv;
using namespace std;


vector <Vec3f> houghCerchi(Mat imgInput, double raggio_min, double raggio_max, double t_canny_max, double threshold){

	int N = imgInput.rows, M = imgInput.cols;
	int raggio = raggio_max - raggio_min + 1;
	int size[3] = {raggio,N,M};
	Mat acc = Mat::zeros(3, size, CV_64F);
	Mat imgOutput = Mat::zeros(imgInput.size(), imgInput.type());


	for(int i=0; i<N; i++)
		for(int j=0; j<M; j++)
			imgOutput.at<uchar>(i,j) = 255;

	for(int x = 0; x<N; x++)
		for(int y = 0; y<M; y++)
			if(imgInput.at<uchar>(x,y) > t_canny_max)
				for(int r=raggio_min; r<=raggio_max; r++)
					for(int t=0; t<=360; t++){

						int a = abs(x - r * cos(t * CV_PI/180));
						int b = abs(y - r * sin(t * CV_PI/180));
						acc.at<double>(r - raggio_min, a, b)++;
					}

	vector <Vec3f> cerchi;		

	for(int i=0; i<raggio; i++)
		for(int j=0; j<N; j++)
			for(int k=0; k<M; k++)
				if(acc.at<double>(i,j,k) > threshold)
					cerchi.push_back(Vec3f(i+raggio_min,j,k));
				

		
	
	return cerchi;



}



int main ( int argc, char **argv){


	double t_min = 0.0, t_max = 0.0, threshold = 0.0, raggio_min=0.0, raggio_max=0.0;
	Mat imgInput(imread( argv[1], 1));
	Mat imgOutput(imgInput.clone());
	vector <Vec3f> cerchi;

	if(argc  != 2){
		perror("Error: not enough arguments. Insert an img\n");
		exit(-1);
	}

	if( !imgInput.data ){
		cout<<"No img data"<<endl;
		return -1;
	}



	cout<<"Inserisci valori soglie per Canny: ";
	cin>>t_min>>t_max;
	cout<<"Inserisci soglia per hough: ";
	cin>>threshold;
	cout<<"Inserisci valori raggio min e raggio max: ";
	cin>>raggio_min>>raggio_max;

	Canny(imgInput,imgOutput,t_min,t_max,3);

	namedWindow("Display img", 0);
	imshow("Display img", imgInput);

	namedWindow("Canny", 0);
	imshow("Canny", imgOutput);

	cerchi = houghCerchi(imgOutput,raggio_min,raggio_max,t_max,threshold);
	
	for(int i=0; i<cerchi.size(); i++){

		//CENTRO DELLA CIRCONFERENZA
		Point centro_circ(cvRound(cerchi[i][2]), cvRound(cerchi[i][1]));
		int raggio = cvRound(cerchi[i][0]);

		circle(imgInput, centro_circ, 3, Scalar(0,255,0), -1, 8, 0);
		circle(imgInput, centro_circ, raggio, Scalar(0,0,255),2,8,0);

	}	

	imgOutput = imgInput.clone();
	
	namedWindow("Hough", 0);
	imshow("Hough", imgOutput);



	waitKey(0);


	return 0;

}
