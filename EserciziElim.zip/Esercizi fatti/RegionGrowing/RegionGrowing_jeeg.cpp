#include <iostream>
#include <opencv2/opencv.hpp>
#include <math.h>
#include <time.h>

using namespace std;
using namespace cv;

const int numSeed = 2;
int* seed;
Mat regions, src;
long treshold;

void regionGrowing(int casualRow, int casualCol) {
    if(casualRow > 0) {
        if(regions.at<uchar>(casualRow - 1, casualCol) != seed[0]) {
            if(abs(src.at<uchar>(casualRow - 1, casualCol) - seed[0]) < treshold) {
                regions.at<uchar>(casualRow - 1, casualCol) = seed[0];
                regionGrowing(casualRow - 1, casualCol);
            }
        }
        else
            regions.at<uchar>(casualRow - 1, casualCol) = seed[1];
    }

    if(casualCol > 0) {
        if(regions.at<uchar>(casualRow, casualCol - 1) != seed[0]) {
            if(abs(src.at<uchar>(casualRow, casualCol - 1) - seed[0]) < treshold) {
                regions.at<uchar>(casualRow, casualCol - 1) = seed[0];
                regionGrowing(casualRow, casualCol - 1);
            }
        }
        else
            regions.at<uchar>(casualRow - 1, casualCol) = seed[1];
    }

    if(casualRow < regions.rows - 1) {
        if(regions.at<uchar>(casualRow + 1, casualCol) != seed[0]) {
            if(abs(src.at<uchar>(casualRow + 1, casualCol) - seed[0]) < treshold) {
                regions.at<uchar>(casualRow + 1, casualCol) = seed[0];
                regionGrowing(casualRow + 1, casualCol);
            }
        }
        else
            regions.at<uchar>(casualRow - 1, casualCol) = seed[1];
    }

    if(casualCol < regions.cols - 1) {
        if(regions.at<uchar>(casualRow, casualCol + 1) != seed[0]) {
            if(abs(src.at<uchar>(casualRow, casualCol + 1) - seed[0]) < treshold) {
                regions.at<uchar>(casualRow, casualCol + 1) = seed[0];
                regionGrowing(casualRow, casualCol + 1);
            }
        }
        else
            regions.at<uchar>(casualRow - 1, casualCol) = seed[1];
    }
}

int main(int argc, char** argv) {
    if(argc == 1) {
        cerr << "Usage error" << endl;
        return -1;
    }

    srand((unsigned) time(NULL));

    src = imread(argv[1], 0);

    namedWindow("Src", CV_WINDOW_AUTOSIZE);
    imshow("Src", src);
    waitKey(0);

    regions = src.clone();
    int y, x;

    for(y = 0; y < regions.rows; y++)
        for(x = 0; x < regions.cols; x++)
            regions.at<uchar>(y, x) = 255;

    seed = new int[numSeed];

    int avg;
    for(y = 0; y < src.rows; y++)
        for(x = 0; x < src.cols; x++)
            avg += src.at<uchar>(y, x);
    avg = avg / (src.rows * src.cols);

    int varianza;
    for(y = 0; y < src.rows; y++)
        for(x = 0; x < src.cols; x++)
            varianza += pow(src.at<uchar>(y,x) - avg, 2);

    int casualRow, casualCol;
    for(int i = 0; i < numSeed; i++) {
        casualRow = rand() % (src.rows);
        casualCol = rand() % (src.cols);
        seed[i] = src.at<uchar>(casualRow, casualCol);
        regions.at<uchar>(casualRow, casualCol) = seed[i];
    }

    treshold = 2 * varianza;

    regionGrowing(casualRow, casualCol);

    namedWindow("Region Growing", CV_WINDOW_AUTOSIZE);
    imshow("Region Growing", regions);
    waitKey(0);

    return 0;
}
