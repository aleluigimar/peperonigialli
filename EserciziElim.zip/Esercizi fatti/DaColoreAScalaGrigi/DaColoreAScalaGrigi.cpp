#include <iostream>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>


using namespace cv;
using namespace std;



Mat convertiInGrigi(Mat imgInput){

	Mat imgOutput = Mat::zeros(imgInput.size(),CV_8U);
	int N = imgInput.rows, M = imgInput.cols;

	for(int i=0; i<N; i++)
		for(int j=0; j<M; j++){
			int avg = (imgInput.at<Vec3b>(i,j).val[0] + imgInput.at<Vec3b>(i,j).val[1] + imgInput.at<Vec3b>(i,j).val[2]) / 3;
			imgOutput.at<uchar>(i,j) = avg;
		}


	return imgOutput;



}



int main ( int argc, char **argv){


	Mat imgInput(imread( argv[1], 1));
	Mat imgOutput;

	if(argc  != 2){
		perror("Error: not enough arguments. Insert an img\n");
		exit(-1);
	}

	if( !imgInput.data ){
		cout<<"No img data"<<endl;
		return -1;
	}


	imgOutput = convertiInGrigi(imgInput);
	

	namedWindow("Display img", 0);
	imshow("Display img", imgInput);

	namedWindow("Scala di grigi", 0);
	imshow("Scala di grigi", imgOutput);

	waitKey();


	return 0;

}
