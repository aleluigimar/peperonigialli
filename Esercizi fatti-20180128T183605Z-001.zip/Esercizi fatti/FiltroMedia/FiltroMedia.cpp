#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;


int main(int argc , char **argv)
{
	if(argc != 2)
	{
		cout<<"Inserire immagine";
		return -1;
	}
	Mat imageInput(imread( argv[1], CV_LOAD_IMAGE_GRAYSCALE ));
	
	if(!imageInput.data)
	{
		cout<<"No image data";
		return -1;
	}
	
	Mat media;
	imageInput.copyTo(media);	
	for(int i=1;i<imageInput.rows-1;i++)
	{
		for(int j=1;j<imageInput.cols-1;j++)
		{
			uchar vector[9];
			
			vector[0]= imageInput.at<uchar>(i,j);
			vector[1]= imageInput.at<uchar>(i-1,j);
			vector[2]= imageInput.at<uchar>(i+1,j);
			
			vector[3]= imageInput.at<uchar>(i,j-1);
			vector[4]= imageInput.at<uchar>(i,j+1);
			
			vector[5]= imageInput.at<uchar>(i-1,j-1);
			vector[6]= imageInput.at<uchar>(i+1,j+1);
			
			vector[7]= imageInput.at<uchar>(i-1,j+1);
			vector[8]= imageInput.at<uchar>(i+1,j-1);		
		
			uchar val = (vector[0]+vector[1]+vector[2]+vector[3]+vector[4]+vector[5]+vector[6]+vector[7]+vector[8])/9;
			media.at<uchar>(i,j)=val;		
		}
	}
	
	namedWindow("Original",CV_WINDOW_AUTOSIZE);
	imshow("Original",imageInput);
	namedWindow("myMedia",CV_WINDOW_AUTOSIZE);
	imshow("myMedia",media);	
	waitKey(0);
	return 0;
	
}