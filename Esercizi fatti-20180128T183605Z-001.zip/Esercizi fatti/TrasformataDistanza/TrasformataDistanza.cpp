#include <stdio.h>
#include <iostream>
#include <cmath>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>


using namespace cv;
using namespace std;




Mat bianco_e_nero(Mat imgInput){

	Mat imgOutput = imgInput.clone();
	int N = imgInput.rows, M = imgInput.cols;
	int threshold = 220;

	for(int i=0; i<N; i++)
		for(int j=0; j<M; j++)
			if(imgInput.at<uchar>(i,j)>threshold)
				imgOutput.at<uchar>(i,j) = 0;
			else
				imgOutput.at<uchar>(i,j) = 255;
	
	return imgOutput;
}


int pixelMax(Mat imgInput){

	int N = imgInput.rows, M = imgInput.cols;
	int max = imgInput.at<uchar>(0,0);

	for(int i=0; i<N; i++)
		for(int j=0; j<M; j++)
			if(imgInput.at<uchar>(i,j)>max)
				max = imgInput.at<uchar>(i,j);
	
	return max;



}


Mat trasformataDistanza(Mat imgInput){

	Mat imgOutput(imgInput.clone());
	int N = imgInput.rows, M = imgInput.cols;

	//SCANSIONE DIRETTA
	for(int i=1; i<N; i++)
		for(int j=1; j<M; j++)
			if(imgInput.at<uchar>(i,j)!=0)
				imgInput.at<uchar>(i,j) = min((int)imgInput.at<uchar>(i,j-1),(int)imgInput.at<uchar>(i-1,j))+1;

	//SCANSIONE INVERSA
	for(int i=N-1; i>=0; i--)
		for(int j=M-1; j>=0; j--)
			if(imgInput.at<uchar>(i,j)!=0){
				imgInput.at<uchar>(i,j) = min((int)imgInput.at<uchar>(i+1,j)+1,(int)imgInput.at<uchar>(i,j));
				imgInput.at<uchar>(i,j) = min((int)imgInput.at<uchar>(i,j+1)+1,(int)imgInput.at<uchar>(i,j));
			}

	
	//IMMAGINE IN SCALA DI GRIGI
	int max = pixelMax(imgInput);
	for(int i=0; i<N; i++)
		for(int j=0; j<M; j++)
			imgOutput.at<uchar>(i,j) = imgInput.at<uchar>(i,j) * 255/max;


	return imgOutput;



}




int main ( int argc, char **argv){


	Mat imgInput(imread( argv[1], 0));
	Mat imgOutput(imgInput.clone());
	Mat imgDT = Mat::zeros(imgInput.rows,imgInput.cols,imgInput.type());

	if(argc  != 2){
		perror("Error: not enough arguments. Insert an img\n");
		exit(-1);
	}

	if( !imgInput.data ){
		cout<<"No img data"<<endl;
		return -1;
	}



	imgOutput = bianco_e_nero(imgInput);

	namedWindow("Display img", 0);
	imshow("Display img", imgInput);

	namedWindow("Bianco e nero", 0);
	imshow("Bianco e nero", imgOutput);

	imgDT = trasformataDistanza(imgOutput);
	
	namedWindow("Trasformata distanza", 0);
	imshow("Trasformata distanza", imgDT);

	waitKey();


	return 0;

}
