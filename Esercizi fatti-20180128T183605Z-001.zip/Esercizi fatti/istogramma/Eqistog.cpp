#include <stdio.h>
#include <iostream>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

#define LMAX 256

using namespace cv;
using namespace std;

/*ALGORITMO DI EQUALIZZAZIONE DELL'ISTOGRAMMA

Con questo algoritmo prendiamo una immagine in input e ne calcoliamo l'istogramma.
Successivamente, usiamo l'istogramma calcolato per calcolare l'istogramma in output, cioè l'istogramma con i numeri di occorrenze delle intensità luminose tali che il contrasto dell' immagine sia migliorato.
Infine, usiamo l'istogramma di output per costruire l'immagine di output.*/


void calcolaIstogramma(Mat src, int barre[]) {
	//src = matrice dell'immagine di input
	//barre = array di contatori delle occorrenze dei valori di intensità luminosa (che sono gli indici)
	for (int i=0; i<src.rows; i++) {
		for (int j=0; j<src.cols; j++) {
			barre[(int)src.at<uchar>(i,j)]++;
		}
	}
}

/*int transform(int pixel, int N, int M){

	return round(((LMAX-1)/(N*M))*pixel);

}*/

//FUNZIONE CHE TRASFORMA I VALORI DI INTENSITA' LUMINOSA
void scaleIstOutput(float istogrInput[], int istogrOutput[], int dim){

	for(int i=0; i<LMAX; i++){
		istogrOutput[i] = ((istogrInput[i] - istogrInput[0]) / (dim-1)) * (LMAX - 1);
	}
 }



int main ( int argc, char **argv){

	int N, M, x, y, barre[LMAX] = {0}, istogrOutput[LMAX] = {0};
	float istogrInput[LMAX] = {0.0}, Tx;
	Mat imageInput(imread( argv[1], CV_LOAD_IMAGE_GRAYSCALE ));
	Mat imageOutput(imageInput.clone());
	Mat imageOutputOCV(imageInput.clone());


	if(argc  != 2){
		perror("Error: not enough arguments. Insert an image\n");
		exit(-1);
	}

	if( !imageInput.data ){
		cout<<"No image data"<<endl;
		return -1;
	}

	N = imageInput.rows;
	M = imageInput.cols;

	cout<<"Righe immagine: "<<N<<endl<<"Colonne immagine: "<<M<<endl;


	calcolaIstogramma(imageInput, barre);

	int k;
	istogrInput[0] = barre[0];

	//QUI CALCOLIAMO L'ISTOGRAMMA DELL'IMMAGINE DI INPUT
	for(k=1; k< LMAX; k++){
		istogrInput[k] = istogrInput[k-1] + (float)barre[k];
	}

	//QUI CALCOLIAMO L'ISTOGRAMMA DELL'IMMAGINE DI OUTPUT, CIOE' MIGLIORATA
	scaleIstOutput(istogrInput, istogrOutput, N * M);


	//QUI RICOSTRUIAMO L'IMMAGINE MIGLIORATA DALL' ISTOGRAMMA DI OUTPUT
	for(int i=0; i < N ; i++)
		for(int j=0; j < M; j++){
			imageOutput.at<uchar>(i,j) = istogrOutput[(int)imageOutput.at<uchar>(i,j)];
		}

	//VISUALIZZIAMO I RISULTATI
	namedWindow("Display Image");
	imshow("Display Image", imageInput);
	namedWindow("Processed Image", WINDOW_AUTOSIZE + 10);
	imshow("Processed Image", imageOutput);

	equalizeHist(imageInput, imageOutputOCV);
	namedWindow("Image Processed with OCV", WINDOW_AUTOSIZE + 10);
	imshow("Image Processed with OCV", imageOutputOCV);

	waitKey(0);
	destroyAllWindows();

	return 0;

}
