#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <vector>
#include <iostream>

using namespace cv;
using namespace std;

int main (int argc, char** argv) {
	Mat src(imread(argv[1],0));
	Mat des(Mat::zeros(src.size(), src.type()));

	srand(time(NULL));

	int x = rand()%src.rows;
	int y = rand()%src.cols;
	Vec2d puntoIniziale(x,y);
	int threshold = 10;

	vector<Vec2d> coordinate;
	vector<Vec2d> coordinateAnalizzate;
	coordinate.push_back(puntoIniziale);
	//printf("coordinate: %lf - %lf\n", coordinate[0].val[0], coordinate[0].val[1]);
	while (coordinate.size() != 0) {
		Vec2d puntoEstratto(coordinate[0].val[0], coordinate[0].val[1]);
		coordinate.erase(coordinate.begin());
		int check = 0;
		for (int i = 0; i < coordinateAnalizzate.size(); i++)
		{
			if (coordinateAnalizzate[i] == puntoEstratto) {
				check = 1;
			}
		}
		if (check == 0) {
			coordinateAnalizzate.push_back(puntoEstratto);
			des.at<uchar>(puntoEstratto.val[0],puntoEstratto.val[1]) = src.at<uchar>(puntoEstratto.val[0],puntoEstratto.val[1]);
			if (puntoEstratto.val[0] > 0) {
				// in alto a sinistra
				int sqm = 0;
				if (puntoEstratto.val[1] > 0) {
					sqm =
						(
							src.at<uchar>(puntoEstratto.val[0]-1, puntoEstratto.val[1]-1)
														-
							src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1])
						)
							*
						(
							src.at<uchar>(puntoEstratto.val[0]-1, puntoEstratto.val[1]-1)
														-
							src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1])
						);
					if (sqm < threshold) {
						Vec2d puntoDaInserire(puntoEstratto.val[0]-1, puntoEstratto.val[1]-1);
						coordinate.push_back(puntoDaInserire);
					}
				}
				// in alto al centro
				sqm =
					(
						src.at<uchar>(puntoEstratto.val[0]-1, puntoEstratto.val[1])
													-
						src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1])
					)
						*
					(
						src.at<uchar>(puntoEstratto.val[0]-1, puntoEstratto.val[1])
													-
						src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1])
					);
				if (sqm < threshold) {
					Vec2d puntoDaInserire(puntoEstratto.val[0]-1, puntoEstratto.val[1]);
					coordinate.push_back(puntoDaInserire);
				}
				// in alto a destra
				if(puntoEstratto.val[1] < src.cols-1){
					sqm =
						(
							src.at<uchar>(puntoEstratto.val[0]-1, puntoEstratto.val[1]+1)
														-
							src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1])
						)
							*
						(
							src.at<uchar>(puntoEstratto.val[0]-1, puntoEstratto.val[1]+1)
														-
							src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1])
						);
					if (sqm < threshold) {
						Vec2d puntoDaInserire(puntoEstratto.val[0]-1, puntoEstratto.val[1]+1);
						coordinate.push_back(puntoDaInserire);
					}
				 }
			}
			if (puntoEstratto.val[0] < src.rows-1) {
				int sqm = 0;
				// in basso a sinistra
				if (puntoEstratto.val[1] > 0) {
					sqm =
						(
							src.at<uchar>(puntoEstratto.val[0]+1, puntoEstratto.val[1]-1)
														-
							src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1])
						)
							*
						(
							src.at<uchar>(puntoEstratto.val[0]+1, puntoEstratto.val[1]-1)
														-
							src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1])
						);
					if (sqm < threshold) {
						Vec2d puntoDaInserire(puntoEstratto.val[0]+1, puntoEstratto.val[1]-1);
						coordinate.push_back(puntoDaInserire);
					}
				}
				// in basso al centro
				sqm =
					(
						src.at<uchar>(puntoEstratto.val[0]+1, puntoEstratto.val[1])
													-
						src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1])
					)
						*
					(
						src.at<uchar>(puntoEstratto.val[0]+1, puntoEstratto.val[1])
													-
						src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1])
					);
				if (sqm < threshold) {
					Vec2d puntoDaInserire(puntoEstratto.val[0]+1, puntoEstratto.val[1]);
					coordinate.push_back(puntoDaInserire);
				}
				// in basso a destra
				if (puntoEstratto.val[1] < src.cols-1) {
					sqm =
						(
							src.at<uchar>(puntoEstratto.val[0]+1, puntoEstratto.val[1]+1)
														-
							src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1])
						)
							*
						(
							src.at<uchar>(puntoEstratto.val[0]+1, puntoEstratto.val[1]+1)
														-
							src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1])
						);
					if (sqm < threshold) {
						Vec2d puntoDaInserire(puntoEstratto.val[0]+1, puntoEstratto.val[1]+1);
						coordinate.push_back(puntoDaInserire);
					}
				}
			}
			if (puntoEstratto.val[1] > 0) {
				int sqm = 0;
				// a sinistra in alto
				if (puntoEstratto.val[0] > 0) {
					sqm =
						(
							src.at<uchar>(puntoEstratto.val[0]-1, puntoEstratto.val[1]-1)
														-
							src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1])
						)
							*
						(
							src.at<uchar>(puntoEstratto.val[0]-1, puntoEstratto.val[1]-1)
														-
							src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1])
						);
					if (sqm < threshold) {
						Vec2d puntoDaInserire(puntoEstratto.val[0]-1, puntoEstratto.val[1]-1);
						coordinate.push_back(puntoDaInserire);
					}
				}
				// a sinistra al centro
				sqm =
					(
						src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1]-1)
													-
						src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1])
					)
						*
					(
						src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1]-1)
													-
						src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1])
					);
				if (sqm < threshold) {
					Vec2d puntoDaInserire(puntoEstratto.val[0], puntoEstratto.val[1]-1);
					coordinate.push_back(puntoDaInserire);
				}
				// a sinistra in basso
				if (puntoEstratto.val[0] < src.rows-1) {
					sqm =
						(
							src.at<uchar>(puntoEstratto.val[0]+1, puntoEstratto.val[1]-1)
														-
							src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1])
						)
							*
						(
							src.at<uchar>(puntoEstratto.val[0]+1, puntoEstratto.val[1]-1)
														-
							src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1])
						);
					if (sqm < threshold) {
						Vec2d puntoDaInserire(puntoEstratto.val[0]+1, puntoEstratto.val[1]-1);
						coordinate.push_back(puntoDaInserire);
					}
				}
			}
			if (puntoEstratto.val[1] < src.cols-1) {
				int sqm = 0;
				// a destra in alto
				if (puntoEstratto.val[0] > 0) {
					sqm =
						(
							src.at<uchar>(puntoEstratto.val[0]-1, puntoEstratto.val[1]+1)
														-
							src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1])
						)
							*
						(
							src.at<uchar>(puntoEstratto.val[0]-1, puntoEstratto.val[1]+1)
														-
							src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1])
						);
					if (sqm < threshold) {
						Vec2d puntoDaInserire(puntoEstratto.val[0]-1, puntoEstratto.val[1]+1);
						coordinate.push_back(puntoDaInserire);
					}
				}
				// a destra al centro
				sqm =
					(
						src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1]+1)
													-
						src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1])
					)
						*
					(
						src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1]+1)
													-
						src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1])
					);
				if (sqm < threshold) {
					Vec2d puntoDaInserire(puntoEstratto.val[0], puntoEstratto.val[1]+1);
					coordinate.push_back(puntoDaInserire);
				}
				// a destra in basso
				if (puntoEstratto.val[0] < src.rows-1) {
					sqm =
						(
							src.at<uchar>(puntoEstratto.val[0]+1, puntoEstratto.val[1]+1)
														-
							src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1])
						)
							*
						(
							src.at<uchar>(puntoEstratto.val[0]+1, puntoEstratto.val[1]+1)
														-
							src.at<uchar>(puntoEstratto.val[0], puntoEstratto.val[1])
						);
					if (sqm < threshold) {
						Vec2d puntoDaInserire(puntoEstratto.val[0]+1, puntoEstratto.val[1]+1);
						coordinate.push_back(puntoDaInserire);
					}
				}
			}
		}
	}

	imshow("Immagine originale", src);
	imshow("Region Growing", des);

	waitKey();

	return  0;
}
