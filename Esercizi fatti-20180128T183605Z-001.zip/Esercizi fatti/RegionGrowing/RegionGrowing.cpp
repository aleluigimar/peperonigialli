#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <iostream>
#include <vector>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

float calcolaMedia(int N, int M, Mat img){

  float avg = 0.0;

  for(int i=0; i<N; i++)
    for(int j=0; j<M; j++)
      avg += (float)img.at<uchar>(i,j);

  return avg / (N*M);

}

float calcolaVarianza(int N,int M, int avg, Mat img){

  float varianza = 0.0;

  for(int i=0; i<N; i++)
    for(int j=0; j<M; j++)
      varianza += pow((float)img.at<uchar>(i,j) - avg, 2);

  return varianza;

}

void regionGrowing(int x, int y, Mat imgInput, Mat imgOutput, Mat mask, int seed, float threshold){

    for(int i = -1; i <= 1; i++)
      for(int j = -1; j<= 1; j++)
        if((x+i)>=0 && (x+i)<imgInput.rows)
          if((y+j)>=0 && (y+j)<imgInput.cols)
              if(abs(seed - imgInput.at<uchar>(x+i,y+j)) < threshold && mask.at<uchar>(x+i,y+j)==0){
                mask.at<uchar>(x+i,y+j) = 1;
                imgOutput.at<uchar>(x+i,y+j) = imgInput.at<uchar>(x+i,y+j);
                regionGrowing(x+i,y+j,imgInput,imgOutput,mask,seed,threshold);
              }

}


int main(int argc, char const *argv[]) {

  int seedPixel_X = 166;
  int seedPixel_Y = 438;
  int seed = 0;
  float avg = 0.0, varianza = 0.0, threshold = 0.0;

  if(argc!=2){
    cout<<"Input image needed";
    exit(-1);
  }

  srand((unsigned)time(NULL));

  Mat imgInput(imread(argv[1],0)), imgOutput = Mat::zeros(imgInput.size(), imgInput.type());
  Mat mask = Mat::zeros(imgInput.size(),imgInput.type());
  int N = imgInput.rows, M = imgInput.cols;

  namedWindow("Input image", 0);
  imshow("Input image", imgInput);
  


  if(!imgInput.data){
    perror("Error with image");
    exit(-1);
  }

  avg = calcolaMedia(N,M,imgInput);
  cout<<"Media: "<<avg<<endl;
  varianza = calcolaVarianza(N,M,avg,imgInput);
  cout<<"Varianza: "<<varianza<<endl;
  threshold = 10.0;
  cout<<"threshold: "<<threshold<<endl;


  // while(imgInput.at<uchar>(seedPixel_X,seedPixel_Y) >= 238){
  //   seedPixel_X = rand() % N;
  //   seedPixel_Y = rand() % M;
  // }

  mask.at<uchar>(seedPixel_X,seedPixel_Y) = 255;
  imgOutput.at<uchar>(seedPixel_X,seedPixel_Y) = imgInput.at<uchar>(seedPixel_X,seedPixel_Y);
  seed = imgInput.at<uchar>(seedPixel_X,seedPixel_Y);

  cout<<"Pixel i-simo "<<seed<<", Coordinate: "<<seedPixel_X<<", "<<seedPixel_Y<<endl;
 	namedWindow("mask image", 0);
  imshow("mask image", mask);


  regionGrowing(seedPixel_X,seedPixel_Y,imgInput,imgOutput,mask,seed,threshold);

  namedWindow("Output image", 0);
  imshow("Output image", imgOutput);

  waitKey(0);
  destroyAllWindows();

  return 0;
}
