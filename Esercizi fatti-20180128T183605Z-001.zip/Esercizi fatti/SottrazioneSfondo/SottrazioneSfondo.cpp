#include <iostream>
#include <cmath>
#include <vector>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>


using namespace cv;
using namespace std;



Mat sottrazioneSfondo(Mat *frames){

    Mat sfondo = Mat::zeros(frames[0].size(),frames[0].type());
    sfondo = (frames[0] + frames[1]) / 2;
    Mat differenze = Mat::zeros(Size(640,360),CV_8U);

    int N = sfondo.rows, M = sfondo.cols;

    for(int i = 0; i<N; i++)
        for(int j = 0; j<M; j++){
            int diff_blue = abs(sfondo.at<Vec3b>(i,j).val[0] - frames[2].at<Vec3b>(i,j).val[0]);
            int diff_green = abs(sfondo.at<Vec3b>(i,j).val[1] - frames[2].at<Vec3b>(i,j).val[1]);
            int diff_red = abs(sfondo.at<Vec3b>(i,j).val[2] - frames[2].at<Vec3b>(i,j).val[2]);

            if(diff_blue < 60 && diff_green < 60 && diff_red < 60)
                differenze.at<uchar>(i,j) = 0;
            else
                differenze.at<uchar>(i,j) = 255;
        }


    return differenze;


}



int main ( int argc, char **argv){

    VideoCapture video(argv[1]);
    Mat frames[50], framesToAnalize[3], sfondo;
    
	if(argc  != 2){
		perror("Error: not enough arguments. Insert an img\n");
		exit(-1);
	}

    if(!video.isOpened()){
        cout<<"Video is not opened";
        exit(-1);
    }


    for(int i=0; i<50; i++){
        video >> frames[i];
        resize(frames[i], frames[i], Size(640, 360), 0, 0, INTER_CUBIC);

    }

    framesToAnalize[0] = frames[0];
    framesToAnalize[1] = frames[24];
    framesToAnalize[2] = frames[49];

    sfondo = sottrazioneSfondo(framesToAnalize);

    namedWindow("Sfondo estratto", 0);
    imshow("Sfondo estratto", sfondo);
    waitKey();


    // for(;;){
        
    //     video >> frames; //estrai frames
    //     namedWindow("frames",0);
    //     imshow("frames", frames);
    //     if(waitKey(30) >= 0) break;
    // }


	return 0;

}
