#include <stdio.h>
#include <iostream>
#include <math.h>
#include <vector>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>


using namespace cv;
using namespace std;


Mat houghRette(Mat imgInput, double t_canny_max, double threshold){

	int N = imgInput.rows, M = imgInput.cols;
	Mat imgOutput = Mat::zeros(imgInput.size(), imgInput.type());

	cout<<"Ciao ciao";

	for(int i=0; i<N; i++)
		for(int j=0; j<M; j++)
			imgOutput.at<uchar>(i,j) = 255;


	vector <Vec2d> rette;
	double raggio = N > M ? N : M;
	double rho = raggio * sqrt(2.0);
	int teta = 180;
	Mat acc = Mat::zeros(rho,teta,CV_8U);


	for(int y = 0;	y < N;	y++)
		for(int x = 0;	x < M;	x++){
			if(imgInput.at<uchar>(x,y) > t_canny_max)
				for(int t = 0; t < teta; t++){
					double r = abs((double)x * cos((double)t * CV_PI/180) + (double)y * sin((double)t * CV_PI/180));
					acc.at<uchar>(round(r),t)++;
				}
		 }



	for(int x = 0; x < acc.rows; x++)
		for(int y = 0; y < acc.cols; y++)
			if(acc.at<uchar>(x,y) >= threshold)
				rette.push_back(Vec2d((double)x,(double)y * CV_PI/180));

	cvtColor(imgInput,imgOutput,CV_GRAY2BGR);


	for(int i = 0; i < rette.size(); i++){

				double p = rette[i][0];
				teta = rette[i][1];

				double x0 = p * cos(teta);
				double y0 = p * sin(teta);

				Point p1,p2;


				p1.x = round(x0 + 1000 * (-sin(teta)));
				p1.y = round(y0 + 1000 * cos(teta));
				p2.x = round(x0 - 1000 * (-sin(teta)));
				p2.y = round(y0 - 1000 * cos(teta));

				line(imgOutput,p1,p2,Scalar(0,0,255),1,CV_AA);

	}

	return imgOutput;



}



int main ( int argc, char **argv){


	double t_min = 0.0, t_max = 0.0, threshold = 0.0;
	Mat imgInput(imread( argv[1], 0));
	Mat imgOutput(imgInput.clone());

	if(argc  != 2){
		perror("Error: not enough arguments. Insert an img\n");
		exit(-1);
	}

	if( !imgInput.data ){
		cout<<"No img data"<<endl;
		return -1;
	}



	cout<<"Inserisci valori soglie per Canny: ";
	cin>>t_min>>t_max;
	cout<<"Inserisci soglia per hough: ";
	cin>>threshold;

	Canny(imgInput,imgOutput,t_min,t_max,3);

	namedWindow("Display img", 0);
	imshow("Display img", imgInput);

	namedWindow("Canny", 0);
	imshow("Canny", imgOutput);

	imgOutput = houghRette(imgOutput,t_max,threshold);

	namedWindow("Hough", 0);
	imshow("Hough", imgOutput);



	waitKey(0);


	return 0;

}
