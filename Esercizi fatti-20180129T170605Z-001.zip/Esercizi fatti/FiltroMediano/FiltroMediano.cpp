#include <stdio.h>
#include <iostream>
#include <vector>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace	cv;

int main(int argc, char const *argv[])
{
if(argc != 2)
	{
		cout<<"Inserire immagne";
		return -1;
	}
	Mat imageInput(imread( argv[1], CV_LOAD_IMAGE_GRAYSCALE ));
	
	if(!imageInput.data)
	{
		cout<<"No image data";
		return -1;
	}
	Mat imageOutput(imageInput.clone());
	int N,M;
	vector<int> imgVector(3*3,0);

	N=imageInput.rows;
	M=imageInput.cols;
	for(int i=1;i<N-1;i++)
	{
		for(int j=1;j<M-1;j++)
		{
		
			
			imgVector[0]= imageInput.at<uchar>(i,j);
			imgVector[1]= imageInput.at<uchar>(i-1,j);
			imgVector[2]= imageInput.at<uchar>(i+1,j);
			
			imgVector[3]= imageInput.at<uchar>(i,j-1);
			imgVector[4]= imageInput.at<uchar>(i,j+1);
			
			imgVector[5]= imageInput.at<uchar>(i-1,j-1);
			imgVector[6]= imageInput.at<uchar>(i+1,j+1);
			
			imgVector[7]= imageInput.at<uchar>(i-1,j+1);
			imgVector[8]= imageInput.at<uchar>(i+1,j-1);		
		
			std::sort(imgVector.begin(),imgVector.end());
			imageOutput.at<uchar>(i,j)=imgVector[4];	
		}
	}
	
	namedWindow("Original",CV_WINDOW_AUTOSIZE);
	imshow("Original",imageInput);
	namedWindow("myMediano",CV_WINDOW_AUTOSIZE);
	imshow("myMediano",imageOutput);	
	waitKey(0);

	destroyAllWindows();
	return 0;
	



}
